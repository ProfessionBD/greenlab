
<section class="subscribe_wrap">
    <div class="container"><div class="row">
            <div class="col-lg-6">
                <h3>Sign up for the <a href="#">99PrintsLETTER</a>&nbsp;for special offers, news and inspiration</h3>
            </div>
            <div class="col-lg-6">
                <form>
                    <input type="email" name="subscribe" placeholder="example@99PrintBD.com">
                    <button class="email_bttn" data-test-id="newsletter-sign-up-form-submit"><i class="fa fa-angle-right"></i></button>
                </form>
            </div>
        </div></div>
</section><!-- /.subscribe_wrap -->


<section class="footer_social_wrap">
    <div class="container"><div class="row">
            <div class="col-lg-6">
                <div class="">
<!--                    <img src="images/icon_05.png">-->
                </div>
            </div>
            <div class="col-lg-6">
                <div class="footer_social tRight">
                    <ul class="aRight">
                        <li><a href="#"><i class="fa fa-facebook-square"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter-square"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin-square"></i></a></li>
                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#"><i class="fa fa-youtube-square"></i></a></li>
                    </ul>
                </div>
            </div>
        </div></div>
</section><!-- /.socials_wrap -->






<section class="widgets_wrap">
    <div class="container"><div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="wid_box">
                    <h3>Widgets One Title</h3>
                    <ul>
                        <li><a href="#"> All Products </a> </li>
                        <li> <a href="#"> Business Cards </a> </li>
                        <li> <a href="#"> Square Business Cards </a> </li>
                        <li> <a href="#"> Letterpress Business Cards </a> </li>
                        <li> <a href="#"> Luxe by 99Prints </a> </li>
                        <li> <a href="#"> MiniCards </a> </li>
                        <li> <a href="#"> Flyers </a> </li>
                    </ul>
                </div>
            </div><!-- /.col-lg-3 -->
            <div class="col-lg-3 col-md-6">
                <div class="wid_box">
                    <h3>Widgets Three Title</h3>
                    <ul>
                        <li><a href="#"> Three All Products </a> </li>
                        <li> <a href="#"> Business Cards </a> </li>
                        <li> <a href="#"> Square Business Cards </a> </li>
                        <li> <a href="#"> Letterpress Business Cards </a> </li>
                        <li> <a href="#"> Luxe by 99Prints </a> </li>
                        <li> <a href="#"> MiniCards </a> </li>
                        <li> <a href="#"> Flyers </a> </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="wid_box">
                    <h3>Widgets Four Title</h3>
                    <ul>
                        <li><a href="#"> Four All Products </a> </li>
                        <li> <a href="#"> Business Cards </a> </li>
                        <li> <a href="#"> Square Business Cards </a> </li>
                        <li> <a href="#"> Letterpress Business Cards </a> </li>
                        <li> <a href="#"> Luxe by 99Prints </a> </li>
                        <li> <a href="#"> MiniCards </a> </li>
                        <li> <a href="#"> Flyers </a> </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="wid_box">
                    <h3>Widgets Title</h3>
                    <ul>
                        <li><a href="#"> All Products </a> </li>
                        <li> <a href="#"> Business Cards </a> </li>
                        <li> <a href="#"> Square Business Cards </a> </li>
                        <li> <a href="#"> Letterpress Business Cards </a> </li>
                        <li> <a href="#"> Luxe by 99Prints </a> </li>
                        <li> <a href="#"> MiniCards </a> </li>
                        <li> <a href="#"> Flyers </a> </li>
                    </ul>
                </div>
            </div><!-- /.col-lg-3 -->
        </div></div>
</section><!-- /.widgets_wrap -->



<!-- FOOTER -->
<footer class="footer_wrap">
    <div class="container"><div class="row">
            <div class="col-lg-6">
                <div class="footer_left">
                    <p>&copy; 99PrintBD Limited, 1st Floor, Road#02, Sec#12, Uttara-Dhaka. Registered in Bangladesh, Company Number: 000000</p>
                </div>
            </div><!-- /.col-lg-6 -->
            <div class="col-lg-6">
                <nav class="navbar footer_nav">
                    <ul>
                        <li><a href="#">Terms &amp; Conditions</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Fonts</a></li>
                        <li><a href="#">Sitemap</a></li>
                        <li><a href="#">Company information</a></li>
                    </ul>
                </nav>
            </div><!-- /.col-lg-6 -->
        </div></div>
</footer><!-- /.footer_wrap -->

// For Carousel for Ftrd_Icon_Flex
jQuery(window).load(function() {

  jQuery('.flexslider').flexslider({
    animation: "slide",
    animationLoop: true,
    // itemWidth: 410,
    itemMargin: 5,
    minItems: 1,
    maxItems: 4,
    controlNav: true,
    directionNav:true,
  }); //.flexslider



// For Clients Logo for Clients_Logo
  jQuery('.clients_logo').flexslider({
  //   animation: "slide",
  //   animationLoop: true,
  //   itemWidth: 150,
  //   itemMargin: 5,
  //   minItems: 1,
  //   maxItems: 5,
  //   controlNav: false,
		// directionNav:false,
  }); //.clients_logo

});

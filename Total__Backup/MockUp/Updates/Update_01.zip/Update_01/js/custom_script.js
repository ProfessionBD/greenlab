// For Carousel for Ftrd_Icon_Flex
jQuery(window).load(function() {

  jQuery('.ftrd_icon_flex').flexslider({
    animation: "fade",
    animationLoop: true,
    itemWidth: 290,
    itemMargin: 7,
    minItems: 1,
    maxItems: 5,
  }); //.ftrd_icon_flex



// For Clients Logo for Ftrd_Icon_Flex
  jQuery('.clients_logo').flexslider({
    animation: "slide",
    animationLoop: true,
    itemWidth: 150,
    itemMargin: 5,
    minItems: 1,
    maxItems: 5,
    controlNav: false,
		directionNav:false,
  }); //.clients_logo

});
